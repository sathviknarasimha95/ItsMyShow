<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);
$movie = $_POST['m_name'];
 
$sql = "select t_name,time_1,time_2,time_3,m_fare from theatre_fetch where mov_1='$movie' OR mov_2='$movie' OR mov_3='$movie'";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){
array_push($result,
array('t_name'=>$row[0],
'time_1'=>$row[1],
'time_2'=>$row[2],
'time_3'=>$row[3],
'm_fare'=>$row[4]
));
}
 
echo json_encode(array("result"=>$result));
 
mysqli_close($con);
 
?>