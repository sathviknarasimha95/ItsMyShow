<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

 $booking_email = $_POST['booking_email'];
 $booking_movie = $_POST['booking_movie'];
 $booking_card = $_POST['booking_card'];

 $booking_fare=$_POST['booking_fare'];
 $seata=$_POST['s1'];
 $seatb=$_POST['s2'];
 $seatc=$_POST['s3'];
 $seatd=$_POST['s4'];
 $seate=$_POST['s5'];
 $t_name = $_POST['t_name'];
 $time = $_POST['time'];

if($t_name=='thiba')
{
$t_fetch='thiba_fetch';
}
else if($t_name=='sterling')
{
$t_fetch='sterling_fetch';
}
else if($t_name=='inox')
{
$t_fetch='inox_fetch';
}
else if($t_name=='DRC')
{
$t_fetch='drc_fetch';
}
else if($t_name=='PVR')
{
$t_fetch='pvr_fetch';
}
if($time=='10:00')
{
$t_time='time_1';
}
else if($time=='1:00')
{
$t_time='time_2';
}
else if($time=='5:00')
{
$t_time='time_3';
}


$sql = "INSERT INTO `booking_db` (`book_id`, `booking_email`, `booking_movie`,`booking_card`,`booking_movietime`,`booking_fare`) VALUES (NULL, '$booking_email', '$booking_movie',md5('$booking_card'),'$time','$booking_fare');";
$result = mysqli_query($con, $sql) or die("Error in Selecting " . mysqli_error($connection));
if($seata!=0)
{
$sql1 = "UPDATE `$t_fetch` SET `$t_time` = '1' WHERE `$t_fetch`.`b_id` = $seata";
$result1 = mysqli_query($con, $sql1) or die("Error in Selecting " . mysqli_error($connection));
}
if($seatb!=0)
{
$sql2 = "UPDATE `$t_fetch` SET `$t_time` = '1' WHERE `$t_fetch`.`b_id` = $seatb";
$result2 = mysqli_query($con, $sql2) or die("Error in Selecting " . mysqli_error($connection));
}
if($seatc!=0)
{
$sql3 = "UPDATE `$t_fetch` SET `$t_time` = '1' WHERE `$t_fetch`.`b_id` = $seatc";
$result3 = mysqli_query($con, $sql3) or die("Error in Selecting " . mysqli_error($connection));
}
if($seatc!=0)
{
$sql4 = "UPDATE `$t_fetch` SET `$t_time` = '1' WHERE `$t_fetch`.`b_id` = $seatd";
$result4 = mysqli_query($con, $sql4) or die("Error in Selecting " . mysqli_error($connection));
}
if($seatd!=0)
{
$sql5 = "UPDATE `$t_fetch` SET `$t_time` = '1' WHERE `$t_fetch`.`b_id` = $seate";
$result5 = mysqli_query($con, $sql5) or die("Error in Selecting " . mysqli_error($connection));
}

if(isset($result1)||isset($result2)||isset($result3) ||isset($result4)||isset($result5)){
echo 'successful';
}else{

echo 'failure';
}

?>