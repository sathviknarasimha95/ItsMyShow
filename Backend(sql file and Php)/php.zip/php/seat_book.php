<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$t_name = $_POST['t_name'];
$time = $_POST['time'];


if($t_name=='thiba')
{
$t_fetch='thiba_fetch';
}
else if($t_name=='sterling')
{
$t_fetch='sterling_fetch';
}
else if($t_name=='inox')
{
$t_fetch='inox_fetch';
}
else if($t_name=='DRC')
{
$t_fetch='drc_fetch';
}
else if($t_name=='PVR')
{
$t_fetch='pvr_fetch';
}
if($time=='10:00')
{
$t_time='time_1';
}
else if($time=='1:00')
{
$t_time='time_2';
}
else if($time=='5:00')
{
$t_time='time_3';
}

$sql = "SELECT $t_time FROM ". $t_fetch ."";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){
array_push($result,
array('time'=>$row[0]
));
}
 
echo json_encode(array("result"=>$result));
 
mysqli_close($con);
?>