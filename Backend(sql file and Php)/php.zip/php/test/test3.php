<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$booking_name = 'sathvik';
$booking_email = 'sathviknarasimha@gmail.com';
$booking_movie = 'rustom';
$booking_card = '1865872569875';
$booking_movietime='10:00';


$sql = "INSERT INTO `booking_db` (`book_id`, `booking_name`, `booking_email`, `booking_movie`,`booking_card`,`booking_movietime`) VALUES (NULL, '$booking_name', '$booking_email', '$booking_movie',md5('$booking_card'),'$booking_movietime');";
$result = mysqli_query($con, $sql) or die("Error in Selecting " . mysqli_error($connection));

if(isset($result)){
echo 'successful';
}else{
echo 'failure';
}

?>