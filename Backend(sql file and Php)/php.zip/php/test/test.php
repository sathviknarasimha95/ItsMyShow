<?php
$con = mysqli_connect("localhost","root","","db_1");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
echo @mysql_ping() ? 'true' : 'false';

$sql = "select * from tbl_employee";
$result = mysqli_query($con, $sql) or die("Error in Selecting " . mysqli_error($connection));

//create an array
    $emparray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        $emparray[] = $row;
    }
    echo json_encode($emparray);
?>