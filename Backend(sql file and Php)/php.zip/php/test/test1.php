
<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$t_name = 'thiba';
$time = '9:00';

echo $t_name;
echo $time;

if($t_name=='thiba')
{
$t_fetch='thiba_fetch';
}
else if($t_name=='sterling')
{
$t_fetch='sterling_fetch';
}
else if($t_name=='inox')
{
$t_fetch='inox_fetch';
}
else if($t_name=='DRC')
{
$t_fetch='drc_fetch';
}

echo $t_fetch;

?>