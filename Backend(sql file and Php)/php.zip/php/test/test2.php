<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$sqls = "select points from login_db";

$rese = mysqli_query($con,$sqls);

$data = mysql_fetch_row($rese);

echo $data["points"];

?>