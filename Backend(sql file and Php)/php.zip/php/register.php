<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];



$sql = "INSERT INTO `login_db` (`id`, `username`, `password`, `email`) VALUES (NULL, '$username', '$password', '$email');";
$result = mysqli_query($con, $sql) or die("Error in Selecting " . mysqli_error($connection));

if(isset($result)){
echo 'successful';
}else{
echo 'failure';
}

?>