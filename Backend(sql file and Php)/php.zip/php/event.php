<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);
 
$sql = "select * from event_fetch ";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){
array_push($result,
array('e_id'=>$row[0],
'event_name'=>$row[1],
'organizer'=>$row[2],
'e_place'=>$row[3],
'e_date'=>$row[4],
'e_time'=>$row[5],
'e_fare'=>$row[6]
));
}
 
echo json_encode(array("result"=>$result));
 
mysqli_close($con);
 
?>