<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','itsmyshowdb');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

 
$email = $_POST['username'];
$password = $_POST['password'];
 
$sql = "select * from login_db where email='$email' and password='$password'";
 
$res = mysqli_query($con,$sql);

$check = mysqli_fetch_array($res);

echo $check["points"];
if(isset($check)){
echo '+success login';
}else{
echo 'failure';
} 
mysqli_close($con);
?>